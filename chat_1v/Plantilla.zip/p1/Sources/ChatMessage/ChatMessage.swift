public enum ChatMessage {
    case Init
    case Writer
    case Server
}
