import Foundation

// Read command-line argumens

// Create ChatServer

// Run ChatServer
