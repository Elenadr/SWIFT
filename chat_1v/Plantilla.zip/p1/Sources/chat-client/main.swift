import Foundation

// Read command-line argumens

// Create ChatClient

// Run ChatClient
