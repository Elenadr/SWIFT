//
//   Chat-Server
//   main.swift
//   Elena del Rio
//

import Foundation
import Glibc

let defaultPort = 7667
// Read command-line argumens
guard CommandLine.arguments.count == 2 else{
    print("Usage Error. Bad arguments. Please, try run chat-server <port>")
    exit(1)
}
// Si el usuario mete un puerto erroneo o no valido se sustituye por 7667 por defecto
let port = Int(CommandLine.arguments[1]) ?? defaultPort

do{
    // Create ChatServer
    let chatServer = try ChatServer(port: port)
    // Run ChatServer
    try chatServer.run()
}catch let error{
    print("Network Error\(error)")
}

