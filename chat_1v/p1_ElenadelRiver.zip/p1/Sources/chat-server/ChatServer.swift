//
//  ChatServer.swift
//   Elena del Rio
//

import Foundation
import Socket
import ChatMessage

enum ChatServerError: Error {
    /**
     Thrown on communications error.
     Initialize with the underlying Error thrown by the Socket library.
     */
    case networkError(socketError: Error)
    
    /**
     Thrown if an unexpected message or argument is received.
     For example, the server should never receive a 'Server' message.
     */
    case protocolError
}

class ChatServer {
    let port: Int
    var serverSocket: Socket
    
    var readers = ClientCollectionArray(uniqueNicks: false)
    var writers = ClientCollectionArray(uniqueNicks: true)
    
    init(port: Int) throws {
        self.port = port
        serverSocket = try Socket.create(family: .inet, type: .datagram, proto: .udp)
    }
    
    func run() throws {
        do {
            //Ponemos el server a escuchar en el puerto
            try self.serverSocket.listen(on: self.port)
            //print("Listening on \(port)")
            var buffer = Data(capacity: 1024) //Nuestro buffer es un array de bytes
            repeat{
                //Nos quedamos esperando a conocer la direccion y los bytes que nos envia el cliente
                //Aunque no necesitamos los bytes a priori.
                let (_, address) =  try serverSocket.readDatagram(into: &buffer)
                // Vamos a ver que tipo de mensaje nos esta enviando el client.
                if let clientAddress = address{

                var offset = 0
                //Desempaqueto la cabecera para ver si se trata de un msg INIT o WRITER
                let header = buffer.withUnsafeBytes{ pointer in
                    pointer.load(fromByteOffset: offset, as: ChatMessage.self)
                }
                //Hago la cuenta de hasta donde he leido del buffer
                offset += MemoryLayout<ChatMessage>.size

                //Evaluamos los tipos de mensajes que podemos recibir
                //Si recibimos un init
                if header == ChatMessage.Init{
                    //LEEMOS el nick del cliente
                    let clientNick = buffer[offset...].withUnsafeBytes{pointer in
                        String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
                    }
                    // Si no es reader
                    if clientNick != "reader"{
                        
                        do{
                            //Añadimos a la lista de escritores
                            try self.writers.addClient(address: clientAddress, nick: clientNick)
                            buffer.removeAll()
                            //Damos la bienvenida
                            print("INIT received from \(clientNick)")
                            //Enviamos al client reader el tipo de msg server
                            withUnsafeBytes(of: ChatMessage.Server){ pointer in
                            buffer.append(contentsOf: pointer)
                            }
                            "server".utf8CString.withUnsafeBytes{ pointer in
                            buffer.append(contentsOf: pointer)
                            }
                            //Enviamos el msg de que se ha unido el cliente
                            "\(clientNick) joins the chat".utf8CString.withUnsafeBytes{ pointer in
                            buffer.append(contentsOf: pointer)
                            }
                            //Enviar a todos los clientes lectores el init
                            try self.readers.forEach { (address, _) in
                                try self.serverSocket.write(from: buffer, to: address)
                                }    
                        } catch ClientCollectionError.repeatedClient{
                            print("INIT received from \(clientNick). IGNORED, nick already used ")
                        }
                    }else{
                        //Si es readers, mandamos init
                        print("INIT received from \(clientNick)")
                        //añadimos a la lista de lectores
                        try! self.readers.addClient(address: clientAddress, nick: clientNick)
                    }
                    //Si la cabecera es un writer
                }else if (header == ChatMessage.Writer){
                    //recibimos lo que ha escrito el cliente
                    let input = buffer[offset...].withUnsafeBytes{pointer in
                        String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
                    }
                    //Si el nick esta en la lista de escritores
                    if let clientNick = self.writers.searchClient(address: clientAddress) {
                        //Escribimos el writer.
                        print("WRITER received from \(clientNick): \(input)")
                        buffer.removeAll()
                        //Mandamos los mensajes server par alos readers
                        withUnsafeBytes(of: ChatMessage.Server){ pointer in
                            buffer.append(contentsOf: pointer)
                        }
                        clientNick.utf8CString.withUnsafeBytes{ pointer in
                            buffer.append(contentsOf: pointer)
                        }
                        input.utf8CString.withUnsafeBytes{ pointer in
                            buffer.append(contentsOf: pointer)
                        }
                        //A la lista de lectores se les envia los mensajes writer
                        try self.readers.forEach { (address, _) in
                            try self.serverSocket.write(from: buffer, to: address)
                        }
                    }else {
                       print("WRITER received from unknown client. IGNORED") 
                    }
                    
                //Si no es init ni writer, lanzamos error el server solo puede recibir ese tipo de msgs
                }else{
                    throw ChatServerError.protocolError
                }
            }
            //Vaciamos el buffer
            buffer.removeAll()
            }while true
        } catch let error {
            throw ChatServerError.networkError(socketError: error)
        }
    }
}