//
//  ClientCollectionArray.swift
//  Implementation of ClientCollection that uses an array as the backend.
//   Elena del Rio
//
import Socket

/// Implements a `ClientCollection` using an Array as the backend
struct ClientCollectionArray {
    struct Client {
        var address: Socket.Address
        var nick: String
    }
    
    private var clients = [Client]()
    let uniqueNicks: Bool

    init(uniqueNicks: Bool = true) {
        self.uniqueNicks = uniqueNicks
    }
}

/// ClientCollection functions have to be implemented here
extension ClientCollectionArray: ClientCollection {
    //Añadir cliente
    mutating func addClient(address: Socket.Address, nick: String) throws{
        // Si el uniqueNicks = true, miramos si esta repetido
        if self.uniqueNicks{
            //¿Esta el nick repetido?
            let isNickRepeated = self.clients.contains { $0.nick == nick }
            //Si isNickRepeated == true, lanzamos error
            if isNickRepeated{
                throw ClientCollectionError.repeatedClient
            //Si isNickRepeated == false, añad el cliente a la lista.
            }else{
                self.clients.append(Client(address: address, nick: nick))
            }      
        // Si el uniqueNicks = false, añado el cliente
        }else{
            self.clients.append(Client(address: address, nick: nick))
        }
    }
    //Eliminar cliente
    mutating func removeClient(nick: String) throws{
    // Vamos mirando el indice relativo al nick, y si concide con el nick que le pasamos, lo eliminamos
      if let index = self.clients.firstIndex(where: { $0.nick == nick}){
        self.clients.remove(at: index)
        //en caso contrario, lanzamos error de cliente no encontrado
      }else{
        throw ClientCollectionError.noSuchClient
      }
    }
    // Buscar cliente
    func searchClient(address: Socket.Address) -> String?{
        //Con el filter, acotamos la direccion. Si la direccion esta devolvemos el nick.
        return self.clients.filter {$0.address == address}.map {$0.nick}.first
    }
    //Funcion para cada elemento de la coleccion
    func forEach(_ body: (Socket.Address, String) throws -> Void) rethrows{
        try self.clients.forEach { client in
            try body(client.address, client.nick)}
    }
    
}