//
//  ChatClient.swift
//  Elena del Rio
//

import Foundation
import Socket
import ChatMessage

enum ChatClientError: Error {
    case wrongAddress
    case networkError(socketError: Error)
    case protocolError
}

class ChatClient {
    let host: String
    let port: Int
    let nick: String
    
    init(host: String, port: Int, nick: String) {
        self.host = host
        self.port = port
        self.nick = nick
    }
    
    var isReader: Bool { return nick == "reader" }
    
    func run() throws {
        // Apuntamos la direccion del server
        do {
            guard let serverAddress = Socket.createAddress(for: self.host, on: Int32(port)) else {
                throw ChatClientError.wrongAddress
            }
            // Creamos nuestro client Socket
            let clientSocket = try Socket.create(family: .inet, type: .datagram, proto: .udp)
            var buffer = Data(capacity: 1024)
            //Rellenamos el buffer con el tipo de mensaje
            withUnsafeBytes(of: ChatMessage.Init){ pointer in
                buffer.append(contentsOf: pointer)
            }
            //Rellenamos el buffer con el string del nick
            self.nick.utf8CString.withUnsafeBytes{ pointer in
                buffer.append(contentsOf: pointer)
            }
            //Envio el server
            try clientSocket.write(from: buffer, to: serverAddress)
            //Si el nick no es reader
            if nick != "reader"{
                //creamos una variable para saber cuando escribe el writer .quit
                //Mientras no escribe .quit el final es falso, luego el bucle de escritura esta activo
                var end = false
                // Bucle para escribit
                repeat{
                // El terminator, es para que no se introduzca salto de linea
                print ("Message: ", terminator: "")
                if let input = readLine(){
                    //Mientras que el usuario no escribe .quit
                    if input != ".quit"{
                        //Limpiamos el buffer
                        buffer.removeAll()
                        //Rellenamos buffer con mensaje writer
                        withUnsafeBytes(of: ChatMessage.Writer){pointer in
                            buffer.append(contentsOf: pointer)
                        }
                        //Rellenamos el buffer con el string de lo que ha escrito el user
                        input.utf8CString.withUnsafeBytes{ pointer in
                            buffer.append(contentsOf: pointer)
                        }
                        try clientSocket.write(from: buffer, to: serverAddress) 
                    }else{
                        //si la entrada por teclado es .quit, el final es true
                        end = true
                    }
                } 
                //Mientras end sea falso, se repite el bucle
                }while end == false
                //Cerramos el socket
                clientSocket.close()
            //Si el nick es reader
            // Tiene que recibir del servidor. Solo mensajes server
            }else if nick == "reader"{
                repeat{
                    //Limpiamos el buffer
                    buffer.removeAll()
                    let(bytesRead, address) = try clientSocket.readDatagram(into: &buffer)
                    if let serverAddress = address{
                        var offset = 0
                        //Desempaqueto la cabecera para ver deque tipo d emsg se trata
                        let header = buffer.withUnsafeBytes{ pointer in
                        pointer.load(fromByteOffset: offset, as: ChatMessage.self)
                        }
                        //Hago la cuenta de hasta donde he leido del buffer
                        offset += MemoryLayout<ChatMessage>.size
                        //Solo puedo recibi mensajes SERVER en el reader, asi que ponemos una guarda
                        //Si recibo un mensaje que no es SERVER lanzo error d eprotocolo
                        guard header == ChatMessage.Server else {
                            throw ChatClientError.protocolError
                        }
                        //Leemos el nick 
                        let nick = buffer[offset...].withUnsafeBytes{pointer in
                        String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
                        }
                        offset += nick.count + 1
                        //Leemos el input que escribio el cliente escritor
                        let input = buffer[offset...].withUnsafeBytes{pointer in
                        String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
                        }
                        // Pintamos el nick, los dos puntos y lo que ha escrito
                        print("\(nick): \(input)")
                        }
                }while true
            //Metemos un else, si no es reader ni writer, en principo nunca va a entrar aqui
            //A no ser que acotemos como tiene que ser el nick
            }else{
                print("Chat client, received as argument bad or wrong nick")
                print("Try: 'reader' or '[yourname]' as nick")
                throw ChatClientError.protocolError
            }
        // Si no podemos conectar lanzamos un error de conexion
        }catch let error{
            throw ChatClientError.networkError(socketError: error)
        }
    }
}