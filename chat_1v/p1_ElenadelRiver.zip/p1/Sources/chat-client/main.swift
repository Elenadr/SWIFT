//
//   Chat-Client
//   main.swift
//   Elena del Rio
//
import Foundation
import Glibc

let defaultPort = 7667
// Read command-line argumens
guard CommandLine.arguments.count == 4 else{
    print("Usage Error. Bad arguments. Please, try run chat-client <host><port><nick>")
    exit(1)
}
let host = CommandLine.arguments[1]
var port = Int(CommandLine.arguments[2]) ?? defaultPort
var nick = CommandLine.arguments[3]

// Create ChatClient
let chatClient = (ChatClient(host: host, port: port, nick: nick))

// Run ChatClient
do{
    try chatClient.run()
}catch let error{
    print("Network Error\(error)")
}