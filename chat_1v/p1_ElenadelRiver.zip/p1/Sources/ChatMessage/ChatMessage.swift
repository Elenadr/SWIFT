public enum ChatMessage {
    case Init // Del cliente al servidor
    case Writer //Del cliente al servidor
    case Server //Del servidor a cliente
}
