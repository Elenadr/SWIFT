//
// Banco de pruebas par pilas
// Elena del Rio
// 07/01/2022
//
import Collections


var stringStack = ArrayStack<String>()

// Vamos a apilar
print("Estamos apilando palabras")
stringStack.push("palabras")
stringStack.push("estas")
stringStack.push("apilar")
stringStack.push("a")
stringStack.push("Vamos")

//Imprimimos con foreach
print("")
print(stringStack.forEach{print($0)})
print("")
print("Estamos desapilando palabras")
//Eliminamos
var tryStringPop = stringStack.pop()

print("")
//Imprimirmos ila
print(stringStack.forEach{print($0)})

//Ahora utilizamos una pila de enteros
var intStack = ArrayStack<Int>()

// Vamos a apilar
print("Estamos apilando enteros")
intStack.push(5)
intStack.push(4)
intStack.push(3)
intStack.push(2)
intStack.push(1)

//Imprimimos con foreach
print("")
print(intStack.forEach{print($0)})
print("")
print("Estamos desapilando enteros")
//Eliminamos
var tryPop = intStack.pop()

print("")
//Imprimirmos pila
print(intStack.forEach{print($0)})
