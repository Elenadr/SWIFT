//
// Banco de pruebas para colas
// Elena del Rio
// 07/01/2022
//
import Collections

//Creamos una nueva variable que es una rray de colas de tipo string, de capacidad maxima 5
var stringQueue = ArrayQueue<String>(maxCapacity: 5)

// Vamos a encolar
// Y poner a rueba cap maxima
do{
    try stringQueue.enqueue("Solo")
    try stringQueue.enqueue("caben")
    try stringQueue.enqueue("cinco")
    try stringQueue.enqueue("cinco")
    try stringQueue.enqueue("aqui")
    try stringQueue.enqueue("No quepo")
} catch{
    print("Error, max capacity reached")
}
print("")
print("Esta es nuestra cola ->  \(stringQueue)")
print("")

// Si desencolo pierdo items
var tryStringDequeue = stringQueue.dequeue()
print("")
print("Esta es nuestra cola desencolada ->  \(stringQueue)")

print("")
// Vamos a probar forEach
print("Pintamos la cola")
stringQueue.forEach{print($0)}
print("")
// Vamos a probar contains
print("La cola si contiene 'cinco', esperamos true")
print("\(stringQueue.contains{$0 == "cinco"})")
print("La cola no contiene 'arbol', esperamos false")
print("\(stringQueue.contains{$0 == "arbol"})")
print("La cola no contiene 'Solo', esperamos false")
print("\(stringQueue.contains{$0 == "Solo"})")

print("")
//Probamos findfirst
let five = stringQueue.findFirst{$0 == "cinco"}
print("Devolvemos el PRIMER cinco")
print(five!)
print("Eliminamos TODOS los cincos")
stringQueue.remove{$0 == "cinco"}
//Eliminamos el cinco
print("Pintamos la cola")
stringQueue.forEach{print($0)}
print("")
// Vamos a crear una nueva cola de enteros
var intQueue = ArrayQueue<Int>(maxCapacity: 4)
// Encolamos
do{
    try intQueue.enqueue(19)
    try intQueue.enqueue(9)
    try intQueue.enqueue(10)
    try intQueue.enqueue(24)
}catch{
    print("Max capacity reached")
}
print("Pintamos la cola")
intQueue.forEach{print($0)}
print("")

// probamos findFirst 
let lower = intQueue.findFirst{$0 < 10}
print("Devolvemos el primer numero menor que 10")
print(lower!)

print("")

// probamos remove 
//pintamos cuantos elementos tenemos
print("Tenemos \(intQueue.count) elementos en nuestra  cola")
//Eliminamos el primer elemento menos que 10
(intQueue.remove{$0 < 10})
print("Hemos eliminado un elemento ahora tenemos \(intQueue.count)")

print("Pintamos como queda la cola al eliminar el menor que 10")
intQueue.forEach{print($0)}
print("")
