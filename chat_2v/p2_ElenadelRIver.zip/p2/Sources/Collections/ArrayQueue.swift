//
//   ArrayQueue.swift
//   Elena del Rio
//   28/12/2021
//

public struct ArrayQueue<Element> : Queue{
    private var storage = [Element] ()
    public var maxCapacity: Int

    public init(maxCapacity: Int) {
        self.maxCapacity = maxCapacity
    }

    public var count: Int { return storage.count }

    public mutating func enqueue(_ value: Element) throws {
        // Si los elementos que tengo no alcanzan la maxima capacidad, puedo encolar
        if count != maxCapacity {
            storage.append(value)
        }else{
            throw CollectionsError.maxCapacityReached
        }
    }

    public mutating func dequeue() -> Element?{
        // Si la cuenta es distinta de cerp desencolo
       guard storage.count != 0 else{
            return nil
        }
        return storage.remove(at: 0)
    }
    
    public func forEach(_ body: (Element) throws -> Void) rethrows{
        //recorremos elemento a elemento
        try storage.forEach{ element in
            try body(element)
        }

    }
    // Si contiene, nos devuelve true, si no, nos devolvera false
    public func contains(where predicate: (Element) -> Bool) -> Bool{
        storage.contains(where: predicate)
    }

    public func findFirst(where predicate: (Element) -> Bool) -> Element?{
        storage.first(where: predicate)
    }
    
    public mutating func remove(where predicate: (Element) -> Bool){
        storage.removeAll(where: predicate)
    }
}