//
//   ArrayStack.swift
//   Elena del Rio
//   28/12/2021
//

public struct ArrayStack<Element> : Stack{
    private var storage = [Element] ()

    public init() {

    }
    // En las pilas siempre inserto por la posicion 0
    public mutating func push(_ value: Element){
        storage.insert(value, at: 0)
    }

    //se inserta y se elimina por el mismo sitio, por el principio
    public mutating func pop() -> Element?{
        guard storage.count != 0 else{
            return nil
        }
        return storage.remove(at: 0)
    }
    
    public func forEach(_ body: (Element) throws -> Void) rethrows{
        //recorremos elemento a elemento
        try storage.forEach{ element in
            try body(element)
        }
    }
}