public enum ChatMessage {
    case Init     // Del cliente al servidor 
    case Welcome  // De servidor a cliente
    case Writer   // Del cliente al servidor
    case Server   // Del servidor a cliente
    case Logout   // Del cliente al servidor
}