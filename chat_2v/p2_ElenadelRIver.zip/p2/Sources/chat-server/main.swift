//
//   Chat-Server
//   main.swift
//   Elena del Rio
//   28/12/2021
//
import Foundation
import Glibc
// Read command-line argumens
guard CommandLine.arguments.count == 3 else{
    print("Usage Error. Bad arguments. Please, try run chat-server <port> <maxUsers>")
    exit(1)
}
// Si el usuario mete un puerto erroneo o no valido se sustituye por 7667 por defecto
guard let port = Int(CommandLine.arguments[1]) else{
    print("Usage Error. Bad <port>. Please, use an integer")
    exit(1)
}
guard let maxUsers = Int(CommandLine.arguments[2]), maxUsers >= 2 && maxUsers <= 50 else{
    print("Usage Error. Bad <maxUsers>. Please, try a number between 2 and 50")
    exit(1)
}
do{
    // Create ChatServer
    let chatServer = try ChatServer(port: port, maxUsers: maxUsers)
    // Run ChatServer
    try chatServer.run()
}catch let error{
    print("Network Error\(error)")
}