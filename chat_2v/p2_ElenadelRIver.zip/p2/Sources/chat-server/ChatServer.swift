//
//  ChatServer.swift
//  Elena del Rio
//  09/01/2022
//

import Foundation
import Socket
import ChatMessage
import Collections


enum ChatServerError: Error {
    /**
     Thrown on communications error.
     Initialize with the underlying Error thrown by the Socket library.
     */
    case networkError(socketError: Error)
    
    /**
     Thrown if an unexpected message or argument is received.
     For example, the server should never receive a 'Server' message.
     */
    case protocolError
}

class ChatServer {
    // Estructura para almacenar los lientes activos
    struct ActiveClient{
        var nick: String
        var address: Socket.Address
        var date: Date // Sirve para representar fecha y tiempo
    }

    struct InactiveClient{
        var nick: String
        var date: Date // Sirve para representar fecha y tiempo
    }
    
    let port: Int
    var maxUsers: Int
    var serverSocket: Socket
    // Recibir los mensajes de clientes hilo secundario
    var datagramReader: DatagramReader? = nil
    
    var activeClients: ArrayQueue<ActiveClient>
    var inactiveClients = ArrayStack<InactiveClient>()
    
    init(port: Int, maxUsers: Int) throws {
        self.port = port
        self.maxUsers = maxUsers
        serverSocket = try Socket.create(family: .inet, type: .datagram, proto: .udp)
        self.activeClients =  ArrayQueue<ActiveClient>(maxCapacity: maxUsers)
    }
    
    func run() throws {
    do {
            // Hilo secundario
            //Ponemos el server a escuchar en el puerto
            try self.serverSocket.listen(on: self.port)
            //print("Listening on \(port)")
            self.datagramReader = DatagramReader(socket: self.serverSocket, capacity: 1024){ (buffer, bytesRead, address) in
                self.handler(buffer: buffer, bytesRead: bytesRead, address: address! )
            }

            // HILO PRINCIPAL
            // Leer del teclado y comprobar
            repeat{
                // Lo que escriba por el teclado el usuario es el input
                if let input = readLine(){
                    //Si el input es l o L
                    if input == "l" || input == "L"{
                        //Pintamos en el terminal los clientes activos
                        print("ACTIVE CLIENTS")
                        print("==============")
                        let df = DateFormatter()
                            df.dateFormat = "dd-MMM-yy HH:mm:ss"
                            activeClients.forEach { activeClient in 
                                let (clientHostname, clientPort) = Socket.hostnameAndPort(from: activeClient.address)!
                                print("\(activeClient.nick) (\(clientHostname): \(clientPort)) \(df.string(from: activeClient.date))")
                            }
                    }else if input == "o" || input == "O"{
                        //Pintamos en el terminal los clientes inactivos
                        print("OLD CLIENTS")
                        print("===========")
                        let df = DateFormatter()
                            df.dateFormat = "dd-MMM-yy HH:mm:ss"
                            inactiveClients.forEach { inactiveClients in 
                                print("\(inactiveClients.nick): \(df.string(from: inactiveClients.date))")
                            }
                        }
                    }
                }while true
        } catch let error {
            throw ChatServerError.networkError(socketError: error)
        }
    }
}
extension ChatServer {
    func handler(buffer: Data, bytesRead: Int, address: Socket.Address){
        do{
            ///copia del buffer del datagram
            var bufferForReading = buffer
            //buffer que es un array de bytes
            var bufferForWritting = Data(capacity: 1024) 
            
            //Desempaqueto la cabecera para ver deque tipo de msg se trata
            let header = bufferForReading.withUnsafeBytes{ pointer in
                pointer.load( as: ChatMessage.self)
            }
            bufferForReading = bufferForReading.advanced(by: MemoryLayout<ChatMessage>.size)
            //Evaluamos los tipos de mensajes que podemos recibir
            //Si recibimos un init
            // INIT
            if header == ChatMessage.Init{
                //LEEMOS el nick del cliente
                let clientNick = bufferForReading.withUnsafeBytes{pointer in
                    String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
                }

                // Pregunto al contains s tenemos algun nick igual
                let isClientRepeat = activeClients.contains { $0.nick == clientNick }
                // si tenemos el nick repetido
                if isClientRepeat == true{
                    // lo ignoramos
                    print("INIT received from \(clientNick). IGNORED, nick already used ")
                    bufferForWritting.removeAll()
                    //Mandamos el mensaje al cliente para que actualixce acept a false
                    // y sepa que esta repetido
                    withUnsafeBytes(of: ChatMessage.Welcome){ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    withUnsafeBytes(of: false){ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    try self.serverSocket.write(from: bufferForWritting, to: address)
               // Si no esta repetido
                }else{
                        do{
                            let clientActive = ActiveClient(nick: clientNick, address: address, date: Date())
                            // si no esta repetido, encolamos el cliente
                            try activeClients.enqueue(clientActive)
                            // sI SE ha alcanzado capacidad maxima, hay que hacer huec
                        }catch CollectionsError.maxCapacityReached{
                            // Desencolamos al cliente mas antiguo
                            let oldestClient = activeClients.dequeue()
                            //Meto oldestClient en la lista de inactivos
                            inactiveClients.push(InactiveClient(nick: oldestClient!.nick, date: Date()))
                            // definimos el cliente nuevo
                            let newActiveClient = ActiveClient(nick: clientNick, address: address, date: Date())
                            // Metemos el cliente nuevo a la cola
                            try! activeClients.enqueue(newActiveClient)
                            bufferForWritting.removeAll()
                            //coNTRUIMOS EL mensaje para avisar que ha sido baneado
                            withUnsafeBytes(of: ChatMessage.Server){ pointer in
                                bufferForWritting.append(contentsOf: pointer)
                            }
                            "server".utf8CString.withUnsafeBytes{ pointer in
                                bufferForWritting.append(contentsOf: pointer)
                            }
                            //Enviamos el msg de que ha sido expulsado
                            "\(oldestClient!.nick) banned for being idle too long".utf8CString.withUnsafeBytes{ pointer in
                                bufferForWritting.append(contentsOf: pointer)
                            }
                            // aviso a oldest que ha sido expulsado
                            try self.serverSocket.write(from: bufferForWritting, to: oldestClient!.address)
                            //avisar  los clientes activos en el chat que oldest ha sido baneado
                            try activeClients.forEach { activeClient in
                                if activeClient.nick != clientNick{
                                    try self.serverSocket.write(from: bufferForWritting, to: activeClient.address)
                                }
                            }   
                        }
                    // le doy la bienvenida, al no repetido
                    print("INIT received from \(clientNick): ACCEPTED")
                    bufferForWritting.removeAll()
                    // construyo el mensaje para decir a cliente  que tenemos un new client
                    // ponemos accep a true, no esta repetido
                    withUnsafeBytes(of: ChatMessage.Welcome){ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    withUnsafeBytes(of: true){ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    try self.serverSocket.write(from: bufferForWritting, to: address)

                    bufferForWritting.removeAll()
                    //Construimos el mensaje para avisar a los clientes activos la nueva incorporacion
                    withUnsafeBytes(of: ChatMessage.Server){ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    "server".utf8CString.withUnsafeBytes{ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    // Enviamos el msg de que el nuevo cliente ha entrado en el chat
                    "\(clientNick) joins the chat".utf8CString.withUnsafeBytes{ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    //Enviar a todos los clientes lectores el init del nuevo cliente
                    // al nuevo cliente no le avisamos
                    try activeClients.forEach { activeClient in
                        if activeClient.nick != clientNick{
                            try self.serverSocket.write(from: bufferForWritting, to: activeClient.address)
                        } 
                    } 
                }
            // WRITTER
            }else if (header == ChatMessage.Writer){
                //Leemos el nick 
                let clientNick = bufferForReading.withUnsafeBytes{pointer in
                    String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
                }
                //recibimos lo que ha escrito el cliente
                bufferForReading = bufferForReading.advanced(by: clientNick.utf8.count + 1)
                let input = bufferForReading.withUnsafeBytes{pointer in
                    String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
                }
                //Escribimos el writer.
                
            //Si el nick y la direccion coinciden con unos de nustros clientes activos
                var realClient = activeClients.findFirst{ $0.nick == clientNick && $0.address == address}
                if realClient != nil {
                    //actualizamos la info de los clientes para la fecha
                    // LO ELIMINAMOS Y ACTUALIZAMOS LA FECHA para encolarlo de nuevo
                    activeClients.remove{$0.nick == clientNick}
                    realClient!.date = Date()
                    try! self.activeClients.enqueue(realClient!)
                    //Escribimos el writer.
                    print("WRITER received from \(clientNick): \(input)")
                    
                    //construimos el msg tipo server
                    bufferForWritting.removeAll()
                    withUnsafeBytes(of: ChatMessage.Server){ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    clientNick.utf8CString.withUnsafeBytes{ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    input.utf8CString.withUnsafeBytes{ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    
                    try activeClients.forEach { activeClient in
                        if activeClient.nick != clientNick{
                            try self.serverSocket.write(from: bufferForWritting, to: activeClient.address)
                        }
                    }
                    //si escribe un cliente que no esta activo
                }else {
                   print("WRITER received from unknown client. IGNORED") 
                }
            // LOGUT
            }else if (header == ChatMessage.Logout){
                //Leemos el nick 
                let clientNick = bufferForReading.withUnsafeBytes{pointer in
                    String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
                }
                //Hacemos dobvle autenticacion si tenemos un cliente que coincide nick y address
                let realClient = activeClients.findFirst{ $0.nick == clientNick && $0.address == address}
                // Si tenemos el cliente y escribe .quit
                if realClient != nil{
                    // Escribimos logout
                    print("LOGOUT received from \(clientNick)")
                    // llo eliminamos de activos
                    activeClients.remove{$0.nick == clientNick}
                    // lo metemos en la pila de inactivos
                    inactiveClients.push(InactiveClient(nick: clientNick, date: Date()))
                    bufferForWritting.removeAll()
                    // construimos el mensaje de salida
                    withUnsafeBytes(of: ChatMessage.Server){ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    "server".utf8CString.withUnsafeBytes{ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    // Enviamos el msg de que el cliente incactivo que se va del chat
                    "\(clientNick) leaves the chat".utf8CString.withUnsafeBytes{ pointer in
                        bufferForWritting.append(contentsOf: pointer)
                    }
                    //Enviar a todos los clientes activos
                    try activeClients.forEach { activeClient in
                        try self.serverSocket.write(from: bufferForWritting, to: activeClient.address)
                    }   
                }
            }else{
                throw ChatServerError.protocolError
            }
        }catch let error{
            print(error)
        }
    }
}
