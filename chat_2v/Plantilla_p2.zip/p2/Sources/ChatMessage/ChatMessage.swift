public enum ChatMessage {
    case Init
    case Welcome
    case Writer
    case Server
    case Logout
}
