import Foundation

// Read command-line arguments

// Create ChatClient

// Run ChatClient
