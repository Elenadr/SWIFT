//
//  Queue.swift
//  
//


public protocol Queue {
    associatedtype Element
    
    mutating func enqueue(_ value: Element) 
    mutating func dequeue() -> Element?
    var isEmpty: Bool { get }
    func peek() -> Element?

}
