func processAll<S: Queue>(queue: inout S) {
    var item: S.Element?
    repeat {
        item = queue.dequeue()
        if item != nil {
            print(item!)
        }
    } while item != nil
}


print()
// COmprobamos si  está vacía
print ("¿EStá vacía ?")
print(listQueue.isEmpty)
print(" ")
// IMprimimos primer elemento
print ("Si está vacía imprime nil")
print(listQueue.peek())
print(" ")

var listQueue = ListQueue<Int>()
listQueue.enqueue(11)
listQueue.enqueue(12)
listQueue.enqueue(13)
listQueue.enqueue(14)
listQueue.enqueue(15)
listQueue.enqueue(16)
print("Encolamos y desencolamos con process")
//probamos queue y dequeue
processAll(queue: &listQueue)
print("Si preguntamos ahora is empty es true, porque proecces ha desencolado")
print("")
//encolamos
print("Encolamos dos elementos")
listQueue.enqueue(15)
listQueue.enqueue(16)
print(" ")
//probamos is empty
print ("¿Está vacía ?")

print (listQueue.isEmpty)
print("")
//probamos peek
print("devolvemos con peek")
print(listQueue.peek()!)
// vemos lista
print("")
print("Pintamos list queu")
print(listQueue)
print(" ")

//Podemos crear una cola de cualquier tipo, por ejemplo strrings

var listQueueString = ListQueue<String>()

print("Encolamos frase")
listQueueString.enqueue("Swift")
listQueueString.enqueue("es ")
listQueueString.enqueue("interesante ")
listQueueString.enqueue("y ")
listQueueString.enqueue("complicado ")

//vemos listqueue
print(listQueueString)
print("")
//probamos peek 
print("devolvemos con peek")
print(listQueueString.peek()!)
print(" ")
//comprobamos isEmpty
print ("¿Está vacía ?")
print (listQueueString.isEmpty)
print("")
//comprobamos queue y dequeu
print("Encolamos y desencolamos con processAll")
print("")
processAll(queue: &listQueueString)
print(" ")
//comprobamos isEmpty denuevo
print ("¿Está vacía ?")
print (listQueueString.isEmpty)

