import LinkedList

struct ListQueue<T> : Queue {
    // Lista enlazada
    private var storage = LinkedList<T>()

    mutating func enqueue(_ value: T) {
        storage.append(value)
    }
    
    mutating func dequeue() -> T? {
        storage.pop()
    }
    
    var isEmpty: Bool {
        storage.count == 0
    }
    
    func peek() -> T? {
        guard storage.count > 0 else { return nil }
        return storage.value(at: 0)
    }

}

