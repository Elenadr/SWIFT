class LinkedListNode<Element> {
    var value: Element
    var next: LinkedListNode?

    init(value: Element, next: LinkedListNode<Element>?=nil) {
        self.value = value
        self.next = next
    }
}

extension LinkedListNode: CustomStringConvertible {
    public var description: String {
        return "\(self.value)"
    }
}
