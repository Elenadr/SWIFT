public struct LinkedList<Element> {
    private(set) var head: LinkedListNode<Element>?
    private(set) var tail: LinkedListNode<Element>?
    public var count: Int
    
    public init() {
        count = 0
    }
}

extension LinkedList: CustomStringConvertible {
    public var description: String {
        var result = "["
        if !isEmpty() {
            var node = self.head
            while node?.next != nil {
                result += "\(node!.value), "
                node = node!.next
            }
            result += "\(node!.value)"
        }
        result += "]"
        return result
    }
}

extension LinkedList {
    public func isEmpty() -> Bool {
        return count == 0
    }
}

extension LinkedList {
    public mutating func append(_ value: Element) {
        let newNode = LinkedListNode(value: value)
        
        if let tail = tail {
            tail.next = newNode
        }
        
        tail = newNode
        if head == nil { head = newNode }
        count += 1
    }
}

extension LinkedList {
    public func value(at index: Int) -> Element? {
        guard index >= 0 && index < count else { return nil }

        var node = head
        for _ in 0..<index {
            node = node!.next
        }
        return node!.value
    }
}


extension LinkedList {
    public mutating func pop() -> Element? {
        let node = head
        head = head?.next
        if head == nil { tail = nil }
        if node != nil { count -= 1 }
        return node?.value
    }
}




