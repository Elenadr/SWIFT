import XCTest

import ej3Tests

var tests = [XCTestCaseEntry]()
tests += ej3Tests.allTests()
XCTMain(tests)
