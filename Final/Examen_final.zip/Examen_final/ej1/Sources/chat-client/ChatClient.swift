//
//  ChatClient.swift
//  Elena del Rio
//  09/01/2022
//

import Foundation
import Socket
import ChatMessage
import Dispatch
import Glibc

enum ChatClientError: Error {
    case wrongAddress
    case networkError(socketError: Error)
    case protocolError
    case timeout        // Thrown when the server does not respond to Init after 10s
}

class ChatClient {
    let host: String
    let port: Int
    let nick: String
    
    init(host: String, port: Int, nick: String) {
        self.host = host
        self.port = port
        self.nick = nick
    }
        
    func run() throws {
        do {
            // Nos apuntamos la direccion del server
            guard let serverAddress = Socket.createAddress(for: self.host, on: Int32(port)) else {
                throw ChatClientError.wrongAddress
            }
            // Creamos nuestro client Socket
            let clientSocket = try Socket.create(family: .inet, type: .datagram, proto: .udp)
            // Poner tiempo maximo de espera
            try clientSocket.setReadTimeout(value: 10 * 1000)
            var bufferForReading = Data(capacity: 1024)
            var bufferForWritting = Data(capacity: 1024)
            // INIT
            //Rellenamos el buffer con el tipo de mensaje
            withUnsafeBytes(of: ChatMessage.Init){ pointer in
                bufferForWritting.append(contentsOf: pointer)
            }
            //Rellenamos el buffer con el string del nick
            self.nick.utf8CString.withUnsafeBytes{ pointer in
                bufferForWritting.append(contentsOf: pointer)
            }
            //Envio el server
            try clientSocket.write(from: bufferForWritting, to: serverAddress)
            // welcome
            //Limpiamos el buffer
            bufferForReading.removeAll()
            let(bytesRead, _) = try clientSocket.readDatagram(into: &bufferForReading)
            if bytesRead == 0 && errno == EAGAIN{
                //timeout, server unreacheable
                print("Server unreachable")
            }else{
                //Desempaqueto la cabecera para ver deque tipo d emsg se trata
                let header = bufferForReading.withUnsafeBytes{ pointer in
                    pointer.load(as: ChatMessage.self)
                }
                bufferForReading = bufferForReading.advanced(by: MemoryLayout<ChatMessage>.size)
                //En este momento solo puedo esperar un welcome.
                guard header == ChatMessage.Welcome else {
                    throw ChatClientError.protocolError
                }
                // booleano para compribar si el nick esta repetido
                let accept = bufferForReading.withUnsafeBytes { $0.load (as: Bool.self)}
                // si es true, no esta repetido
                if accept == true{
                    print("Mini-Chat v2.0: Welcome \(self.nick)")
                    let _ =  DatagramReader(socket: clientSocket, capacity: 1024){ (buffer, bytesRead, address) in
                        self.handler(buffer: buffer, bytesRead: bytesRead, address: address!, clientSocket: clientSocket )
                    }
                    //HILO PRINCIPAL
                    //sE DEDICA A LA PARTE ESCRITPRA
                    //creamos una variable para saber cuando escribe el writer .quit
                    //Mientras no escribe .quit el final es falso, luego el bucle de escritura esta activo
                    var end = false
                    // Bucle para escribit
                    repeat{
                    // El terminator, es para que no se introduzca salto de linea
                    print (">> ", terminator: "")
                    if let input = readLine(){
                        let words = input.split(separator: " ")
                        //Mientras que el usuario no escribe .quit
                        if words.first?.lowercased() == "/private"{
                            //Limpiamos el buffer
                            bufferForWritting.removeAll()
                            //Rellenamos buffer con mensaje privatefrom
                            withUnsafeBytes(of: ChatMessage.PrivateFrom){pointer in
                                bufferForWritting.append(contentsOf: pointer)
                            }
                            let nickTo = String(words[1])
                            //Rellenamos el buffer con nick 
                            nickTo.utf8CString.withUnsafeBytes{ pointer in
                                bufferForWritting.append(contentsOf: pointer)
                            }
                            let input = words[2...].joined(separator: " ")
                            //Rellenamos el buffer con el string de lo que ha escrito el user
                            input.utf8CString.withUnsafeBytes{ pointer in
                                bufferForWritting.append(contentsOf: pointer)
                            }
                            //Rellenamos el buffer con nick 
                            
                            nick.utf8CString.withUnsafeBytes{ pointer in
                                bufferForWritting.append(contentsOf: pointer)
                            }                          
                            // lo enviamos a la dir del server
                            try clientSocket.write(from: bufferForWritting, to: serverAddress) 
                        }else if input == ".quit"{
                            //si la entrada por teclado es .quit, el final es true
                            end = true
                        }else {
                                                        //Limpiamos el buffer
                            bufferForWritting.removeAll()
                            //Rellenamos buffer con mensaje writer
                            withUnsafeBytes(of: ChatMessage.Writer){pointer in
                                bufferForWritting.append(contentsOf: pointer)
                            }
                            //Rellenamos el buffer con nick 
                            nick.utf8CString.withUnsafeBytes{ pointer in
                                bufferForWritting.append(contentsOf: pointer)
                            }
                            //Rellenamos el buffer con el string de lo que ha escrito el user
                            input.utf8CString.withUnsafeBytes{ pointer in
                                bufferForWritting.append(contentsOf: pointer)
                            }
                            // lo enviamos a la dir del server
                            try clientSocket.write(from: bufferForWritting, to: serverAddress) 
                            
                        }
                } 
                //Mientras end sea falso, se repite el bucle
                }while end == false
                //LOGOUT
                //Limpiamos el buffer
                bufferForWritting.removeAll()
                //Rellenamos el buffer con el tipo de mensaje logout
                withUnsafeBytes(of: ChatMessage.Logout){ pointer in
                    bufferForWritting.append(contentsOf: pointer)
                }
                //Rellenamos el buffer con el string del nick
                nick.utf8CString.withUnsafeBytes{ pointer in
                    bufferForWritting.append(contentsOf: pointer)
                }
                //Envio el server, le notifico el logut
                try clientSocket.write(from: bufferForWritting, to: serverAddress)  
            }else{
                // si el nick esta repetido avisamos
                print("Mini-Chat v2.0: IGNORED new user \(self.nick), nick already used")
            }
        }
    } catch let error{
        throw ChatClientError.networkError(socketError: error)
    }
}
}

extension  ChatClient {
    func handler(buffer: Data, bytesRead: Int, address: Socket.Address, clientSocket: Socket){
        ///copia del buffer del datagram
        var bufferForReading = buffer
        
       //Desempaqueto la cabecera para ver deque tipo de msg se trata
        let header = bufferForReading.withUnsafeBytes{ pointer in
            pointer.load( as: ChatMessage.self)
        }
        bufferForReading = bufferForReading.advanced(by: MemoryLayout<ChatMessage>.size)
        if header == ChatMessage.Server{
            //Leemos el nick  
            let clientNick = bufferForReading.withUnsafeBytes{pointer in
                String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
            }
            // avanzamos el ofset 
            bufferForReading = bufferForReading.advanced(by: clientNick.utf8.count + 1)
            //Leemos el input que escribio el cliente escritor
            let input = bufferForReading.withUnsafeBytes{pointer in
                String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
            }
            print(" ")
            // Pintamos el nick, los dos puntos y lo que ha escrito
            print("\(clientNick): \(input)")
            
            print(">> ", terminator: "")
            fflush(stdout)
        }else if header == ChatMessage.PrivateTo{
            let nickFrom = bufferForReading.withUnsafeBytes{pointer in
                String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
            }
            bufferForReading = bufferForReading.advanced(by: nickFrom.utf8.count+1)
            //Leemos el input que escribio el cliente escritor
            let input = bufferForReading.withUnsafeBytes{pointer in
                String(cString: pointer.bindMemory(to: UInt8.self).baseAddress!)
            }
            
            //Leemos el input que escribio el cliente escritor

            print ("*PRIVADO* \(nickFrom): \(input)")
            print(">> ", terminator: "")
            fflush(stdout)
        }else{
            print("Error. Invalid ChatMessage.<Type> received. Not known.")
        }
    }
}